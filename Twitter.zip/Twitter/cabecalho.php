<!--
Cabecalho da aplicacao. Aqui sao descritos elementos comuns a todas as outras paginas da aplicacao, como o menu e as especificacoes em CSS do layout das paginas.
-->
<html>
<head>
	<title>Consultas Twitter</title>
	<meta charset="utf-8">
	<link href="https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/user/loja.css" rel="stylesheet" />
	<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
	<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</head>
	<div class="container">
		<div class="principal">
			<ul class="nav nav-tabs">
			  <li role="presentation" class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
					Consultar<span class="caret"></span>
				</a>
				<ul class="dropdown-menu">
					<li role="presentation"><a href="citytrends.php">Topicos populares</a></li>
					<li role="presentation"><a href="queryhashtag.php">Tweets por hashtag</a></li>
					<li role="presentation"><a href="queryword.php?idcliente=&idmesa=">Tweets por palavra</a></li>
					<li role="presentation"><a href="queryphrase.php?prato=&ingrediente=">Tweets por frase</a></li>
				</ul>
			  </li>
			  <li role="presentation" class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
					Plotar<span class="caret"></span>
				</a>
				<ul class="dropdown-menu">
					<li role="presentation"><a href="plothashtag.php?idcliente=">Tweets por hashtag</a></li>
					<li role="presentation"><a href="plotword.php">Tweets por palavra</a></li>
				</ul>
			  </li>
			</ul>
<br><br>
