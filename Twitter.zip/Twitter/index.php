<?php 
include ("cabecalho.php"); 
/*
	Pagina inicial da aplicacao.
*/
?>
<h2>Welcome.</h2>
<?php include ("rodape.php"); ?>