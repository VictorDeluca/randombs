<?php include ("cabecalho.php"); ?>
Procure tweets com a palavra desejada:<br><br>

<form action="queryword.php">
	Palavra: <input type="text" name="word" value="<?=$_GET['word']?>"/>
	<input type="submit" value="Buscar"/>
</form>

<?php
	$word = $_GET['word'];

	$output = exec("python3 /var/www/html/Twitter/query_keyword.py $word");
    	print_r($output);
?>

<?php include ("rodape.php"); ?>
