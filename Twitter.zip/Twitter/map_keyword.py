#Finds targets with a given hashtag, and prints the first ten. Prints only username and text. PHP File will be responsible for the map.

import oauth2
import pprint
import json
import urllib.parse

consumer_key = 'vMr4ThoGERgRFiDab4jKBNJjQ'
consumer_secret = 'UOe5IQeajKjdcy7ki4vNuBLAG4s5LjOPm8gEtLteR0fmmLsoxt'

token_key = '1000953944535945216-ma36YpObpGk70lcW9ZJ43r0vdlIVAM'
token_secret = 'Bwtb94xbh5Ysi8mFekOGSS8XZBdKXJ7sduPraTn704jFD'

consumer = oauth2.Consumer(consumer_key, consumer_secret)
token = oauth2.Token(token_key, token_secret)

client = oauth2.Client(consumer, token)
query = input("Pesquisar: ")
query_parse = urllib.parse.quote(query, safe='')
requisicao = client.request('https://api.twitter.com/1.1/search/tweets.json?q='+query_parse)
decodificar = requisicao[1].decode()
objeto = json.loads(decodificar)

tweets = objeto['statuses']

counter = 0
for tweet in tweets:
    print(tweet['user']['screen_name'])
    print(tweet['text'])
    print("\n")
    counter = counter+1
    if(counter == 10):
        break;






