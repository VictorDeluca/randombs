#Finds the most trending topics in our city

import oauth2
import pprint
import json
import urllib.parse
from pymongo import MongoClient

woeids = {
'Agua Boa': 458322,
'Alagadico': 458352,
'Arumin': 458359,
'Boa Vista': 455936,
'Cajual': 458925,
'Caubi': 459138,
'Chiriri': 459169,
'Condado': 459226,
'Dandanho': 459323,
'Deposito': 431031,
'Jararaca': 459786,
'Jiju': 459807,
'Murupu': 457647,
'Noe': 460246,
'Passarao': 460402,
'Podres': 460525,
'Sao Bento': 461029,
'Sao Luis': 461150,
'Tatu': 461381,
'Uberaba': 461494,
'Uraricoera': 461519,
'Veneza': 461565
}

consumer_key = 'vMr4ThoGERgRFiDab4jKBNJjQ'
consumer_secret = 'UOe5IQeajKjdcy7ki4vNuBLAG4s5LjOPm8gEtLteR0fmmLsoxt'

token_key = '1000953944535945216-ma36YpObpGk70lcW9ZJ43r0vdlIVAM'
token_secret = 'Bwtb94xbh5Ysi8mFekOGSS8XZBdKXJ7sduPraTn704jFD'

consumer = oauth2.Consumer(consumer_key, consumer_secret)
token = oauth2.Token(token_key, token_secret)

client = oauth2.Client(consumer, token)
requisicao = client.request('https://api.twitter.com/1.1/trends/place.json?id=23424768')
decodificar = requisicao[1].decode()
objetos = json.loads(decodificar)

high = 0
answer = []
for objeto in objetos:
    topics = objeto['trends']
    for topic in topics:
        requisicao = client.request('https://api.twitter.com/1.1/search/tweets.json?q="'+topic['query']+'"&place=ef4296e721b70dfe');
        decodificar = requisicao[1].decode()
        objeto1 = json.loads(decodificar)
        tweets = objeto1['statuses']
        if(len(tweets) == high):
            answer.append(topic['name'])
        if(len(tweets) > high):
            answer.clear()
            answer.append(topic['name'])
            high = len(tweets)

for topic in answer:
    print(topic)
